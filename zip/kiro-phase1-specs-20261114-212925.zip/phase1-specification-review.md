# Phase 1 Specification Review Checklist

**Version:** 1.1.0
**Status:** Corrected — Awaiting Independent Re-Review
**Branch:** feature/phase1-specification-planning
**Base commit:** aaaaacb703124fc31b0e757b2bf1739c4fb225c9
**Spec files reviewed:**
- `.kiro/specs/phase1-functional-orchestration/requirements.md`
- `.kiro/specs/phase1-functional-orchestration/design.md`
- `.kiro/specs/phase1-functional-orchestration/tasks.md`
- `docs/planning/phase1-roadmap.md`
**Last Updated:** 2026-11-14
**Supersedes:** v1.0.0 (self-review only)

---

## Review Summary

This document records two review passes:

**v1.0.0 (§1–§9):** Initial self-review by specification author. All sections passed. Marked READY FOR INDEPENDENT SPECIFICATION REVIEW.

**v1.1.0 (§11):** Independent specification remediation. Eight findings identified and resolved by correction pass. Full evidence for each correction is in §11. The final verdict is in §12.

---

## 1. Requirements Completeness

### 1.1 Requirements are numbered and testable

| Check | Result | Notes |
|---|---|---|
| Every requirement has a unique ID | ✅ Pass | IDs: REQ-P1.x, REQ-W1.x, REQ-I1.x, REQ-M1.x, REQ-G1.x, REQ-U1.x, REQ-DB1.x, REQ-S1.x, REQ-T1.x |
| Every requirement has acceptance criteria | ✅ Pass | Each criterion numbered (e.g., P1.1.1) |
| Acceptance criteria are testable (observable outcome) | ✅ Pass | All criteria specify an HTTP status, exit code, return value, or log assertion |
| No criterion relies on subjective judgment | ✅ Pass | Reviewed; all criteria are binary pass/fail |

### 1.2 Scope coverage

| Capability | Required in prompt | Covered in spec |
|---|---|---|
| Persistent project management | ✅ | ✅ REQ-P1.1–P1.6 |
| Workflow orchestration foundation (not autonomous execution) | ✅ | ✅ REQ-W1.1–W1.7; autonomous execution explicitly out of scope |
| Integration execution | ✅ | ✅ REQ-I1.1–I1.6 |
| MCP integration | ✅ | ✅ REQ-M1.1–M1.6 |
| GitHub workflow orchestration | ✅ | ✅ REQ-G1.1–G1.6 |
| Streamlit experience | ✅ | ✅ REQ-U1.1–U1.5 |
| Security requirements | ✅ | ✅ REQ-S1.1–S1.5 |
| Testing requirements | ✅ | ✅ REQ-T1.1–T1.4 |
| Database migrations | ✅ | ✅ REQ-DB1.1–DB1.2 |

### 1.3 Out-of-scope items explicitly stated

| Item | Location | Verdict |
|---|---|---|
| Autonomous AI execution from definition_json | requirements.md Overview + Out of Scope section; REQ-W1.1, REQ-W1.5 | ✅ Explicit with reason |
| ChatGPT / Claude live adapters | roadmap.md "Out of scope" | ✅ Explicit with reason |
| Codex CLI live execution | roadmap.md "Out of scope" | ✅ Explicit with reason |
| Auto PR merge | REQ-S1.4, REQ-G1.5 | ✅ Prohibited by requirement |
| Android, React, TypeScript, Vite | Global constraints header | ✅ Explicit |
| Multi-user access control | roadmap.md "Out of scope" | ✅ Explicit |
| OS-level MCP sandbox isolation | REQ-M1.5, REQ-S1.5, roadmap.md "Out of scope" | ✅ Explicit with reason |

---

## 2. Design Consistency with Repository

### 2.1 Phase 0 architecture preserved

| Check | Result | Notes |
|---|---|---|
| Modular monolith pattern retained | ✅ Pass | design.md §1 and §2 diagram show unchanged layer topology |
| Phase 0 module paths unchanged | ✅ Pass | No Phase 0 file is renamed or deleted |
| `UTCDateTime` TypeDecorator used for all new timestamps | ✅ Pass | Explicitly required in global constraints and each model design |
| `get_db` dependency unchanged | ✅ Pass | design.md §17 "Dependency on Phase 0" |
| `BaseRepository` extended (not replaced) | ✅ Pass | design.md §4 shows extension pattern |
| Phase 0 stub adapters retained as fallbacks | ✅ Pass | REQ-I1.1.6, REQ-I1.4.4, design.md §6 |

### 2.2 New components trace to requirements

| Component | Requirement | Design section |
|---|---|---|
| Workflow, WorkflowRun models | REQ-W1.1, W1.2 | design.md §3.2, 3.3 |
| ApprovalRequest model | REQ-W1.3 | design.md §3.4 |
| WorkflowAuditLog model | REQ-W1.7 | design.md §3.5 |
| RepositoryConfig model | REQ-G1.1 | design.md §3.6 |
| ProjectRepository.list_filtered | REQ-P1.2 | design.md §4.1 |
| WorkflowService state machine | REQ-W1.5 | design.md §9 |
| ApprovalService.resolve | REQ-W1.6 | design.md §5.2 |
| GitHubAdapter live | REQ-I1.1 | design.md §8.1 |
| MCPClient | REQ-M1.2 | design.md §7.2 |
| registry.get_live | REQ-I1.4 | design.md §6 |
| Confirmation gate pattern | REQ-S1.1 | design.md §14.1 |
| Approval gate pattern | REQ-S1.1 | design.md §14.2 |

### 2.3 API contracts complete

| Check | Result | Notes |
|---|---|---|
| All new routes listed in design.md §10 | ✅ Pass | Projects, Workflows, Approvals, Repositories |
| All routes prefixed `/api/v1/` | ✅ Pass | Consistent with Phase 0 |
| No `/merge` route | ✅ Pass | Explicitly absent from §10.4; REQ-S1.4 prohibits it |
| HTTP status codes specified for each route | ✅ Pass | §10 tables include success and error codes |
| ErrorResponse format consistent | ✅ Pass | Same `{"error": ..., "code": ...}` as Phase 0 |

---

## 3. Task-to-Requirement Traceability

The full traceability matrix is in design.md §19. Summary:

| Task | Requirements covered | Design sections referenced |
|---|---|---|
| P1 | REQ-DB1.1, DB1.2, P1.5 | §3.0, §3.1 |
| P2 | REQ-P1.5 | §11.1 |
| P3 | REQ-P1.1–P1.4 | §4.1, §5 |
| P4 | REQ-P1.1–P1.4 | §10.1 |
| P5 | REQ-P1.6, U1.4 | §12.1, §12.2 |
| P6 | REQ-T1.1, T1.2, T1.3, T1.4 | §13 (test files) |
| W1 | REQ-W1.1, W1.2, W1.3, W1.7 | §3.2–3.5 |
| W2 | REQ-DB1.1 | §3.0 |
| W3 | REQ-W1.4, W1.5 | §4.2 |
| W4 | REQ-W1.6, W1.7 | §4.3 |
| W5 | REQ-W1.5, W1.6, W1.7 | §5.1, §5.2 |
| W6 | REQ-T1.1, T1.3, T1.4 | §13 |
| A1 | REQ-W1.4, W1.5 | §10.2, §11.2, §11.3 |
| A2 | REQ-W1.6 | §10.3, §11.4 |
| A3 | REQ-I1.5, S1.1 | §15 |
| A4 | REQ-U1.1, U1.2, U1.3, U1.4 | §12.1, §12.2 |
| A5 | REQ-T1.1, T1.2, T1.4 | §13 |
| I1 | REQ-I1.5, M1.4, M1.5 | §7.4 |
| I2 | REQ-I1.1 | §8.1 |
| I3 | REQ-I1.2, I1.3 | §6.1 |
| I4 | REQ-M1.1–M1.6 | §7 |
| I5 | REQ-I1.4 | §6 |
| I6 | REQ-I1.6, M1.1, S1.2 | §10.5 |
| I7 | REQ-I1.6, U1.5, T1.1, T1.2, S1.2, S1.3, S1.5 | §12.1, §13 |
| G1 | REQ-G1.1, DB1.1 | §3.6, §4.4 |
| G2 | REQ-G1.2–G1.6 | §8 |
| G3 | REQ-G1.1–G1.6 | §10.4 |
| G4 | REQ-U1.5 | §12.1 |
| G5 | REQ-T1.1–T1.4 | §13 |

**Coverage verdict:** Every requirement in `requirements.md` is referenced by at least one task. ✅

---

## 4. Security Requirements Review

| Security requirement | Mechanism specified | Test coverage |
|---|---|---|
| Explicit approval for consequential actions | Confirmation gate (§14.1) + Approval gate (§14.2) | ✅ Named in G5 and A5 ACs |
| Credential ≠ authorization | Explicitly stated in REQ-S1.1, design.md §14.1, roadmap Security Summary | ✅ Design language corrected |
| No hardcoded credentials | Settings SecretStr (§14.3) | ✅ REQ-S1.3 |
| No secrets in logs | RedactSecretsProcessor | ✅ Named test: `test_github_token_not_in_log_records` in I7 |
| Bounded timeouts | Per-adapter timeouts in Settings (REQ-S1.2) | ✅ Named test: `test_github_adapter_timeout_raises_integration_error` in I7 |
| No auto PR merge | No `/merge` endpoint (REQ-S1.4) | ✅ Named test: `test_no_merge_endpoint_exists` in G5 |
| MCP subprocess env isolation (Python-level) | Explicit env, SIGTERM/SIGKILL sequence (§14.4); REQ-S1.5 clarified as env-var only | ✅ Named test: `test_mcp_subprocess_launched_with_explicit_env` in I7 |
| MCP permission allow-list | MCPServerConfig.allowed_tools (REQ-M1.4) | ✅ Named test in I7 |
| Secret interpolation safety | Only SecretStr fields; raise before subprocess if unresolvable (REQ-M1.5) | ✅ Named test: `test_mcp_secret_values_not_in_log_records` in I7 |

---

## 5. Integration Feasibility Check

| Integration | Mode | API documented | Notes |
|---|---|---|---|
| GitHub | `automated_api` | ✅ GitHub REST API v3 (public) | Token required; free tier available |
| Ollama | `automated_api` | ✅ Ollama local REST API (public docs) | No token; local binary required |
| Figma | `automated_api` | ✅ Figma REST API v1 (public) | Token required; free tier available |
| MCP servers | `automated_api` | ✅ MCP Python SDK (public) | stdio transport; server must be installed |
| ChatGPT | `automated_api` | ⬜ Deferred | Requires paid key — not in Phase 1 |
| Codex | `cli_handoff` | ⬜ Stub only | Real CLI execution deferred — not in Phase 1 |
| Claude | `automated_api` | ⬜ Deferred | Requires paid key — not in Phase 1 |
| Kiro | `manual_handoff` | ⬜ No public API | Remains stub |
| NotebookLM | `manual_handoff` | ⬜ No public API | Remains stub |
| Antigravity | `unknown` | ⬜ No public API | Remains stub |
| Google Stitch | `unknown` | ⬜ No public API | Remains stub |

**Verdict:** No unsupported integration is promised in Phase 1. ✅

---

## 6. Phase 0 Regression Check

| Phase 0 component | Phase 1 modification | Risk |
|---|---|---|
| `devflow_core/config.py` | New fields added only | Low — additive |
| `devflow_api/models/project.py` | `tags_json` column added | Low — additive; default value provided |
| `devflow_api/schemas/project.py` | `ProjectResponse` gains `tags`, `created_at`, `updated_at` | Medium — Phase 0 tests that construct `ProjectResponse` manually may need updating. **Mitigation:** `tags` defaults to `[]`; `created_at`/`updated_at` use `datetime`. Reviewer should verify no Phase 0 test constructs `ProjectResponse` directly. |
| `devflow_api/routers/projects.py` | Replaced with live DB version | Medium — Phase 0 router tests assert stub behavior. These tests will need updating in Task P6. This is expected evolution. |
| `devflow_api/adapters/registry.py` | `get_live` added; `get` unchanged | Low — additive |
| `devflow_api/middleware/error_handler.py` | New exception handlers added | Low — additive |
| `devflow_ui/pages/2_Projects.py` | Replaced | Low — Phase 0 smoke test for this page will be updated in P6 |
| `devflow_ui/pages/1_Dashboard.py` | Replaced | Low — Phase 0 smoke test updated in A4/A5 |
| All other Phase 0 files | No modification | None |

**Verdict:** No unmitigated regressions. All identified changes are additive or have explicit mitigation tasks. ✅

---

## 7. Wave Dependency Ordering

| Wave | Prerequisite | Correctly ordered |
|---|---|---|
| Wave 1 | Phase 0 complete | ✅ |
| Wave 2 | Wave 1 merged to `develop` | ✅ |
| Wave 3 | Wave 2 merged to `develop` | ✅ |
| Wave 4 | Wave 3 merged to `develop` | ✅ |
| Wave 5 | Wave 4 merged to `develop` | ✅ |

**Migration ordering verified:**
- Wave 1 creates migration 002, which chains from 001 (Phase 0 head). `alembic upgrade head` in Wave 1 applies only 002. ✅
- Wave 2 creates migrations 003, 004, 005, which chain from 002. After Wave 2, `alembic upgrade head` applies all five migrations. ✅
- Wave 5 task G1 creates the `RepositoryConfig` ORM model. The `repository_configs` table was created by migration 005 in Wave 2. No cross-wave ORM dependency exists. ✅

**Within-wave task dependencies (critical paths):**
- Wave 1: P1 → P2 → P3 → P4 → P5 → P6 (strictly sequential)
- Wave 2: W1 → W2; W1 → W3; W1 → W4; W3 + W4 → W5; W5 → W6
- Wave 3: W2 merged → A1 → A2 → A3; A1 → A4; A1–A4 → A5
- Wave 4: W3 merged → I1 → I2, I3, I4 (parallel) → I5 → I6 → I7
- Wave 5: W4 merged → G1 → G2 → G3 → G4 → G5

**Verdict:** All dependencies correctly ordered. ✅

---

## 8. Implementation Boundary Check

| Check | Result |
|---|---|
| No new Python source files modified | ✅ Confirmed — only `.kiro/specs/`, `docs/planning/`, `docs/reviews/`, `.agents/tasks/` written |
| No test files modified | ✅ Confirmed |
| No `requirements/` files modified | ✅ Confirmed |
| No `alembic/` files modified | ✅ Confirmed |
| No `src/` files modified | ✅ Confirmed |
| `git status` shows only specification and planning files | ✅ Confirmed (see §12 git status) |

---

## 9. Open Questions from v1.0.0

The following questions from the initial self-review remain. Some have been resolved by the correction pass; the remainder require reviewer judgment.

1. **Projects router test evolution:** ✅ Resolved in Task P6. Phase 0 stub tests will be updated for live DB behavior.

2. **Workflow page numbering:** ⬜ Unresolved. Pages 6 and 7 are renamed. Reviewer should confirm whether `6_Workflows.py` / `7_History.py` is the preferred UX or whether new pages should use 11+ to avoid renaming.

3. **MCP SDK dependency version:** ⬜ Unresolved. Task I4 adds `mcp` SDK to `requirements/base.txt`. Reviewer should confirm whether a specific version pin is required or `mcp>=1.0.0` is acceptable.

4. **Ollama availability in CI:** ✅ Resolved. All Ollama tests mock `httpx.AsyncClient`. CI environments without Ollama installed will not break.

5. **GitHub confirmation gate vs approval gate:** ✅ Confirmed by design. REQ-G1.4/G1.5 require `confirmed=True` for direct API calls. Workflow-driven execution uses the `ApprovalRequest` gate. A single action is not double-gated.

---

## 10. Final Decision (v1.0.0)

The initial self-review concluded:

> **READY FOR INDEPENDENT SPECIFICATION REVIEW** (v1.0.0, superseded by v1.1.0 findings)

That verdict was premature. Eight blockers were found in the independent remediation pass. See §11 for details.

---

## 11. Independent Remediation Findings (v1.1.0)

### Finding 1 — Migration chain ordering (CRITICAL) ✅ RESOLVED

**Description:** Migration `005_add_project_tags_column.py` (Wave 1, Task P1) had `down_revision = "004_add_repository_tables"`. Migration 004 is a Wave 2 deliverable. This meant `alembic upgrade head` in Wave 1 would fail because migration 004 did not exist. Task P1 acceptance criterion "alembic upgrade head from Phase 0 schema applies migration 005 without error" was false in the Wave 1 context.

**Documents affected:** requirements.md REQ-DB1.1, REQ-DB1.2; design.md §3; tasks.md Task P1, W2; roadmap.md Wave summary.

**Resolution applied:** Renumbered the tags migration from `005` to `002`. Renumbered Wave 2 migrations from `002–004` to `003–005`. The new chain is: `001_create_initial_tables → 002_add_project_tags_column → 003_add_workflow_tables → 004_add_approval_audit_tables → 005_add_repository_tables`. Migration 002 chains directly from the Phase 0 head revision, allowing Wave 1's `alembic upgrade head` to succeed independently.

**Evidence:** requirements.md REQ-DB1.1 (table of revision IDs and `down_revision` values); design.md §3.0 (migration sequence diagram and table); tasks.md Task P1 (migration content with exact revision IDs), Task W2 (required revision headers for 003–005); roadmap.md Alembic Migration Chain section.

**Remaining limitation:** None. The chain is now independently applicable per wave.

---

### Finding 2 — `--cov-branch` missing from all coverage commands (CRITICAL) ✅ RESOLVED

**Description:** REQ-T1.1 specifies "80% branch coverage" but every coverage command in requirements.md, tasks.md, and the roadmap used `pytest --cov=src --cov-fail-under=80`, which measures line coverage only. `--cov-branch` was absent. The gate was inconsistent with the stated requirement.

**Documents affected:** requirements.md REQ-T1.1.1; tasks.md P6, W6, A5, I7, G5 acceptance criteria and G5 final verification commands.

**Resolution applied:** Replaced every occurrence of `pytest --cov=src --cov-fail-under=80` with `pytest --cov=src --cov-branch --cov-report=term-missing --cov-fail-under=80` throughout all five documents. The canonical form now includes `--cov-branch` (branch coverage measurement) and `--cov-report=term-missing` (readable output) in every task acceptance criterion and verification command.

**Evidence:** requirements.md REQ-T1.1.1; tasks.md P6 AC3, W6 AC3, A5 AC3, I7 AC5, G5 AC2 and final verification commands block.

**Remaining limitation:** `pyproject.toml` and `ci.yml` are not in scope for this specification correction step. Those files must also be updated when implementation begins (add `branch = true` to `[tool.coverage.run]` and add `--cov-branch` to the CI pytest command). This is a known remaining gap in the CI configuration.

---

### Finding 3 — `paused` state inconsistency in WorkflowRun (HIGH) ✅ RESOLVED

**Description:** The state machine diagram in design.md §9 included a `paused` box and a `pause` arrow from `active`, but `paused` was absent from the `WorkflowRun.status` CHECK constraint in requirements.md REQ-W1.2 and design.md §3.3. This was a direct contradiction within the specification.

**Documents affected:** requirements.md REQ-W1.2; design.md §3.3 (SQL), §9 (state machine diagram); tasks.md W1 (model AC4), W2 (migration CHECK constraint).

**Resolution applied:** Removed `paused` from all WorkflowRun contexts. The state machine diagram has been redrawn to show only the six valid WorkflowRun states: `pending`, `running`, `waiting_approval`, `completed`, `failed`, `cancelled`. Added ADR-0009 explaining the decision. Added explicit note in REQ-W1.2 and design.md §3.3 that `paused` is a Workflow definition status (the template), not a WorkflowRun execution status.

**Evidence:** requirements.md REQ-W1.2 (status definitions table, note on absent states); design.md §3.3 (SQL CHECK constraint), §9.1 (WorkflowRun states table with explicit "states NOT present" note), §9.2 (corrected state diagram), ADR-0009; tasks.md W1 AC4, W2 migration content.

**Remaining limitation:** None.

---

### Finding 4 — REQ-S1.5 vague "isolated" claim and `down_revision` values not stated (HIGH) ✅ RESOLVED

**Description (Part A):** REQ-S1.5 described MCP subprocess execution as "bounded and isolated" where "isolated" implied OS-level sandbox isolation (seccomp, namespaces), but only Python-level environment variable scoping was actually specified. This would mislead an implementer.

**Description (Part B):** No document stated the exact `down_revision` string values for Phase 1 migrations. Implementers would have to infer these from the numeric sequence, risking mismatches.

**Documents affected:** requirements.md REQ-S1.5; design.md §14.4; tasks.md Task P1, W2 deliverable specs; roadmap.md Security Summary table.

**Resolution applied (Part A):** Rewrote REQ-S1.5 to describe the actual boundary: "subprocess execution MUST be bounded with explicit environment-variable scoping." Added explicit "Isolation boundary" paragraph clarifying Python-level env isolation only. Added OS-level sandbox isolation to the Out of Scope table. Added the SIGTERM → 5s grace → SIGKILL termination sequence. Updated design.md §14.4 with the same clarifications and the corrected subprocess code example. Updated roadmap Security Summary table with a "Note" column distinguishing authentication from authorization.

**Resolution applied (Part B):** Tasks P1 and W2 now show the exact Python `revision` and `down_revision` string values that must appear in each file. Design.md §3.0 provides the full revision table with exact strings.

**Evidence:** requirements.md REQ-S1.5 (reworded, isolation boundary paragraph); design.md §14.4 (corrected isolation description, subprocess code with SIGTERM/SIGKILL sequence), §3.0 (migration revision table); tasks.md Task P1 (migration content with exact revision = / down_revision = strings), Task W2 (required revision headers section); roadmap.md Out of Scope table, Security Summary table.

**Remaining limitation:** OS-level sandbox isolation is deferred. The spec correctly documents this deferral.

---

### Finding 5 — Sixth audit event type `approval_requested` not named (MEDIUM) ✅ RESOLVED

**Description:** REQ-W1.7 required "every status transition on WorkflowRun or ApprovalRequest" to generate an audit log entry. `ApprovalService.request_approval` transitions the run to `waiting_approval` and must log this. Five event types were named in the requirements; `approval_requested` was described in design.md §16 as a structlog event but was not listed as a required `WorkflowAuditLog` event type. The count of six event types implied by the original user request was not satisfied.

**Documents affected:** requirements.md REQ-W1.7; design.md §16 (observability); tasks.md W5 (key implementation notes), W6 (required test cases).

**Resolution applied:** Added `approval_requested` as the sixth named audit event type to requirements.md REQ-W1.7 (required audit event types table, acceptance criterion W1.7.4). Updated design.md §16 (required audit event types table). Updated tasks.md W5 (key implementation notes: "ApprovalService.request_approval logs approval_requested audit event"). Added `test_request_approval_logs_approval_requested` to W6 required test cases.

**Evidence:** requirements.md REQ-W1.7 (required audit event types table, W1.7.4); design.md §16 (required audit event types table); tasks.md W5 AC2, W6 required test cases.

**Remaining limitation:** None.

---

### Finding 6 — Timeout test and subprocess env-isolation test not named in task ACs (MEDIUM) ✅ RESOLVED

**Description:** REQ-S1.2 required bounded adapter timeouts; REQ-S1.5.1 required explicit env scoping. Neither requirement had a named test case in any task's acceptance criteria or required test case list. Without named tests, implementers could pass coverage gates without verifying these security properties.

**Documents affected:** tasks.md I7 required test cases and acceptance criteria.

**Resolution applied:** Added four named security-critical test cases to Task I7 with explicit names and cross-references to the security requirements they verify:
- `test_github_adapter_timeout_raises_integration_error` (REQ-S1.2)
- `test_github_token_not_in_log_records` (REQ-S1.3.2)
- `test_mcp_subprocess_launched_with_explicit_env` (REQ-S1.5.1, REQ-S1.5.4)
- `test_mcp_secret_values_not_in_log_records` (REQ-M1.5.3)

Also added REQ-S1.2.6 to requirements.md (timeout test requirement) and REQ-S1.5.4 (subprocess env test requirement). Added I7 AC6 requiring all four security-critical tests to pass.

**Evidence:** requirements.md REQ-S1.2.6, REQ-S1.5.4; tasks.md I7 "Required test cases (security-critical — must be named)" section, I7 AC6.

**Remaining limitation:** None.

---

### Finding 7 — Roadmap security table conflated credential presence with authorization (LOW) ✅ RESOLVED

**Description:** The roadmap Security Summary table listed "Credential present in Settings" as the authorization mechanism for live adapter calls. Having a credential is an authentication prerequisite, not an authorization decision. The language implied that setting `GITHUB_TOKEN` authorized GitHub actions, which is incorrect.

**Documents affected:** docs/planning/phase1-roadmap.md Security Summary table; requirements.md REQ-S1.1; design.md §14.1.

**Resolution applied:** Rewrote the roadmap Security Summary table row for live adapter calls to show `confirmed=True` or approved `ApprovalRequest` as the authorization mechanism, with a "Note" column clarifying that credential presence is authentication only. Added explicit authorization/authentication distinction paragraph to requirements.md REQ-S1.1 and design.md §14.1 (ADR-0005 rationale updated).

**Evidence:** roadmap.md Security Summary table (Note column); requirements.md REQ-S1.1 "Distinction between credentials and authorization" block; design.md §14.1 "Authorization model" note, ADR-0005 rationale.

**Remaining limitation:** None. This was a documentation inaccuracy; the design itself (using `confirmed=True` as the gate) was correct.

---

### Finding 8 — `PUT /projects/{id}` null-clear semantics undocumented (LOW) ✅ RESOLVED

**Description:** `ProjectUpdate` has all fields as `str | None = None`, meaning `null` and absent are semantically identical (both map to `None` in Python and both skip the field). There was no explicit statement of this behavior. An implementer could interpret `{"description": null}` as "clear the description field" rather than "skip this field."

**Documents affected:** requirements.md REQ-P1.3; tasks.md Task P3 AC3, Task P2 (ProjectUpdate schema notes).

**Resolution applied:** Added explicit "Null semantics" paragraph to requirements.md REQ-P1.3 explaining that `null` = skip (not clear). Added REQ-P1.3.5 acceptance criterion: `PUT /api/v1/projects/{id}` with `{"description": null}` does NOT clear the existing description. Added null semantics comment to `ProjectUpdate` schema in tasks.md Task P2. Added `test_update_project_null_field_does_not_clear` to Task P6 required test cases.

**Evidence:** requirements.md REQ-P1.3 "Null semantics" paragraph, REQ-P1.3.5; tasks.md Task P2 (ProjectUpdate schema comment), Task P3 AC3, Task P6 required test cases.

**Remaining limitation:** None. This is now explicitly documented as intended behavior.

---

## 12. Final Decision

**Git working tree status (specification-only branch):**
- Branch: `feature/phase1-specification-planning`
- Modified/created: `.kiro/specs/phase1-functional-orchestration/requirements.md`, `design.md`, `tasks.md`; `docs/planning/phase1-roadmap.md`; `docs/reviews/phase1-specification-review.md` (this document); `.agents/tasks/phase1-spec-correction-report.md` (new)
- No `src/`, `tests/`, `alembic/`, `.github/`, `pyproject.toml` files modified

**All eight findings resolved:** ✅

**Remaining open decisions for reviewer:**

1. **Workflow page numbering (from v1.0.0):** Pages 6 and 7 renamed to `6_Workflows.py` / `7_History.py`. Reviewer should confirm whether this is preferred over adding new pages at 11+.

2. **MCP SDK version pin:** Task I4 adds `mcp` SDK. Reviewer should specify whether `mcp>=1.0.0` is acceptable or a specific version is required.

3. **`pyproject.toml` and `ci.yml` not in scope:** `branch = true` must be added to `[tool.coverage.run]` in `pyproject.toml` and `--cov-branch` added to the CI pytest command before implementation begins. These files are outside the specification-only scope of this correction step.

4. **MCP server binary trust:** REQ-M1.5 and design.md §14.4 state that operator-configured MCP binaries are trusted and DevFlow AI does not verify signatures. Reviewer should confirm this trust model is acceptable.

---

## **READY FOR INDEPENDENT RE-REVIEW**

All eight blockers identified in the independent remediation pass are resolved. The specification is internally consistent on migration IDs, state machine, approval policy, coverage command, and MCP boundaries. Implementation MUST NOT begin until this review is independently approved and the reviewer has cleared the remaining open decisions above.
